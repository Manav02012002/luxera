"""
Luxera 3D Viewer Demo Application

Run with: python -m luxera.viewer.demo
"""

import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSpinBox, QDoubleSpinBox, QGroupBox,
    QSplitter, QStatusBar
)
from PySide6.QtCore import Qt

from luxera.viewer.widget import LuxeraGLWidget, create_demo_scene


class ViewerDemoWindow(QMainWindow):
    """Demo window for 3D viewer."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Luxera 3D Viewer")
        self.setMinimumSize(1000, 700)
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QHBoxLayout(central)
        
        # Splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(splitter)
        
        # Left panel - controls
        left_panel = self._create_controls()
        splitter.addWidget(left_panel)
        
        # Right panel - 3D view
        self.gl_widget = LuxeraGLWidget()
        splitter.addWidget(self.gl_widget)
        
        # Set splitter sizes (20% controls, 80% view)
        splitter.setSizes([200, 800])
        
        # Status bar
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("Press F to fit view, R to reset camera, G to toggle grid")
        
        # Load demo scene
        create_demo_scene(self.gl_widget)
    
    def _create_controls(self) -> QWidget:
        """Create control panel."""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Room controls
        room_group = QGroupBox("Room")
        room_layout = QVBoxLayout(room_group)
        
        # Width
        w_layout = QHBoxLayout()
        w_layout.addWidget(QLabel("Width:"))
        self.room_width = QDoubleSpinBox()
        self.room_width.setRange(1, 50)
        self.room_width.setValue(6)
        w_layout.addWidget(self.room_width)
        room_layout.addLayout(w_layout)
        
        # Length
        l_layout = QHBoxLayout()
        l_layout.addWidget(QLabel("Length:"))
        self.room_length = QDoubleSpinBox()
        self.room_length.setRange(1, 50)
        self.room_length.setValue(8)
        l_layout.addWidget(self.room_length)
        room_layout.addLayout(l_layout)
        
        # Height
        h_layout = QHBoxLayout()
        h_layout.addWidget(QLabel("Height:"))
        self.room_height = QDoubleSpinBox()
        self.room_height.setRange(2, 10)
        self.room_height.setValue(2.8)
        l_layout.addWidget(self.room_height)
        room_layout.addLayout(h_layout)
        
        layout.addWidget(room_group)
        
        # Luminaire controls
        lum_group = QGroupBox("Luminaires")
        lum_layout = QVBoxLayout(lum_group)
        
        # Grid X
        gx_layout = QHBoxLayout()
        gx_layout.addWidget(QLabel("Grid X:"))
        self.lum_grid_x = QSpinBox()
        self.lum_grid_x.setRange(1, 10)
        self.lum_grid_x.setValue(2)
        gx_layout.addWidget(self.lum_grid_x)
        lum_layout.addLayout(gx_layout)
        
        # Grid Y
        gy_layout = QHBoxLayout()
        gy_layout.addWidget(QLabel("Grid Y:"))
        self.lum_grid_y = QSpinBox()
        self.lum_grid_y.setRange(1, 10)
        self.lum_grid_y.setValue(3)
        gy_layout.addWidget(self.lum_grid_y)
        lum_layout.addLayout(gy_layout)
        
        layout.addWidget(lum_group)
        
        # Buttons
        btn_layout = QVBoxLayout()
        
        apply_btn = QPushButton("Apply")
        apply_btn.clicked.connect(self._apply_changes)
        btn_layout.addWidget(apply_btn)
        
        fit_btn = QPushButton("Fit View (F)")
        fit_btn.clicked.connect(self.gl_widget.fit_view)
        btn_layout.addWidget(fit_btn)
        
        clear_btn = QPushButton("Clear Scene")
        clear_btn.clicked.connect(lambda: self.gl_widget.clear_scene())
        btn_layout.addWidget(clear_btn)
        
        layout.addLayout(btn_layout)
        
        # Stretch to push controls to top
        layout.addStretch()
        
        # Help text
        help_label = QLabel(
            "Controls:\n"
            "• Left drag: Orbit\n"
            "• Middle drag: Pan\n"
            "• Scroll: Zoom\n"
            "• F: Fit view\n"
            "• R: Reset camera\n"
            "• G: Toggle grid"
        )
        help_label.setStyleSheet("color: gray; font-size: 11px;")
        layout.addWidget(help_label)
        
        return panel
    
    def _apply_changes(self):
        """Apply room and luminaire settings."""
        # Clear and rebuild scene
        self.gl_widget.clear_scene(keep_grid=True)
        
        # Get values
        width = self.room_width.value()
        length = self.room_length.value()
        height = self.room_height.value()
        grid_x = self.lum_grid_x.value()
        grid_y = self.lum_grid_y.value()
        
        # Add room
        self.gl_widget.add_room(width, length, height)
        
        # Add luminaires
        spacing_x = width / (grid_x + 1)
        spacing_y = length / (grid_y + 1)
        
        for i in range(grid_x):
            for j in range(grid_y):
                x = spacing_x * (i + 1)
                y = spacing_y * (j + 1)
                z = height
                self.gl_widget.add_luminaire(x, y, z)
        
        self.gl_widget.fit_view()
        self.status.showMessage(f"Room: {width}x{length}x{height}m, {grid_x*grid_y} luminaires")


def main():
    """Run the demo application."""
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    window = ViewerDemoWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
