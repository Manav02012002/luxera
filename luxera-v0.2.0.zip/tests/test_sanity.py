def test_sanity():
    assert 1 + 1 == 2
