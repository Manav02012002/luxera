"""
Luxera: lighting calculation & validation tools.
"""
